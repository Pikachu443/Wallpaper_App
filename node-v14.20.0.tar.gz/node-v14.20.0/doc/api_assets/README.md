# API Reference Document Assets

## hljs.css

The syntax theme for code snippets in API reference documents.

## style.css

The main stylesheet for API reference documents.
